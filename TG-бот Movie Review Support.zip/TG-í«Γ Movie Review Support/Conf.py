# База данных
Host_DB = ''
User_DB = ''
Password_DB = ''
Name_DB = ''

# Telegram-бот
tg_Token = '7721835080:AAHlLEHXl-1nMIDx4uBg5nZhhsz37vJcfJ4'