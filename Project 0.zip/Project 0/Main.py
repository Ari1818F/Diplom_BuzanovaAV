from dotenv import load_dotenv
import os
import telebot
import mysql.connector
import hashlib
import datetime

load_dotenv()

# Внешние параметры
DB_Host = os.getenv("Host")
DB_User = os.getenv("User")
DB_Password = os.getenv("Password")
DB_Name = os.getenv("Name")

TG_Token = os.getenv("TG_Token")

# БД
def Connect_DB ():
    db = mysql.connector.connect(host=DB_Host, user=DB_User, password=DB_Password, database=DB_Name)

    if db.is_connected():
        return db
    else:
        return None

def Use_DB (db : mysql.connector.connection.MySQLConnection, Qwery : str):
    Cursor = db.cursor()
    Cursor.execute(Qwery)

    if Qwery[0:6].upper() == "SELECT": #SELECT
        Result = Cursor.fetchall()
        Cursor.close()
    
    elif Qwery[0:6].upper() == "INSERT": #INSERT
        db.commit()

        Result = Cursor.lastrowid
        Cursor.close()

    elif Qwery[0:6].upper() in ("UPDATE","DELETE"): #UPDATE и DELETE
        db.commit()

        Result = Cursor.rowcount
        Cursor.close()
    
    else:
        Result = None
        Cursor.close()
    
    return Result

def Close_DB (db : mysql.connector.connection.MySQLConnection):
    db.close()

# Шифрование
def SHA224(data : str):
    return hashlib.sha224(data.encode()).hexdigest()

# Обработка данных
User_Data = {}

def Check_User_Save(Telegram_ID : int):
    if Telegram_ID in User_Data:
        return True
    else:
        return False

def New_User_Save(Telegram_ID : int):
    User_Data[Telegram_ID] = {}

def User_Save_Str (Telegram_ID : int, Name : str, Value : str = ""):
    if Check_User_Save(Telegram_ID):
        Data = User_Data[Telegram_ID]
        Data[Name] = Value
        User_Data[Telegram_ID] = Data

    else:
        New_User_Save(Telegram_ID)
        User_Save_Str(Telegram_ID, Name, Value)

def User_Save_Int (Telegram_ID : int, Name : str, Value : int = 0):
    if Check_User_Save(Telegram_ID):
        Data = User_Data[Telegram_ID]
        Data[Name] = Value
        User_Data[Telegram_ID] = Data

    else:
        New_User_Save(Telegram_ID)
        User_Save_Int(Telegram_ID, Name, Value)

def Check_T_ID (Telegram_ID : int):
    DB = Connect_DB()

    Data = Use_DB(DB, f"Select `telegram_id` from `user` where `telegram_id` = {Telegram_ID}")
    if not Data:
        Close_DB(DB)
        return False
    
    else:
        Close_DB(DB)
        return True
    
def Check_Role (Telegram_ID : int):
    DB = Connect_DB()

    ID = Use_DB(DB, f'Select `role_id` from `user` where `telegram_id` = {Telegram_ID}')
    ID = ID[0][0]

    Role = Use_DB(DB, f"Select `name` from `role` where `id`={ID}")
    Role = Role[0][0]

    Close_DB(DB)
    return Role

def Check_Username (Telegram_ID : int):
    DB = Connect_DB()

    Data = Use_DB(DB, f'Select `username` from `user` where `telegram_id` = {Telegram_ID}')
    Data = Data[0][0]

    Close_DB(DB)
    return Data

def Check_Group (Telegram_ID : int):
    DB = Connect_DB()

    Data = Use_DB(DB, f'Select `group_id` from `user` where `telegram_id` = {Telegram_ID}')
    Data = Data[0][0]

    Close_DB(DB)
    return Data

def Check_Login (Login : str):
    DB = Connect_DB()

    Data = Use_DB(DB, f'Select `username` from `user` where `username` = "{Login}"')
    Data = Data[0][0]

    if not Data:
        Close_DB(DB)
        return False
    else:
        Close_DB(DB)
        return True
    
def Check_Password (Password : str):
    DB = Connect_DB()

    Data = Use_DB(DB, f'Select `password` from `user` where `password` = "{Password}"')
    Data = Data[0][0]

    if not Data:
        Close_DB(DB)
        return False
    else:
        Close_DB(DB)
        return True
    
def Update_User (Telegram_ID: int, Username : str):
    DB = Connect_DB()

    User_Password = Use_DB(DB, f'UPDATE `user` SET `telegram_id` = {Telegram_ID} WHERE `user`.`username` = "{Username}"')

    Close_DB(DB)

def Reg (Username : str, Password : str, FIO : str, Group : int, Telegram_ID: int):
    DB = Connect_DB()

    Use_DB(DB, f'INSERT INTO `user` (`id`, `username`, `password`, `fio`, `group_id`, `role_id`, `telegram_id`) VALUES (NULL, "{Username}", {Password}, {FIO}, {Group}, "1", {Telegram_ID})')

    Close_DB(DB)

def Check_Schedule (Group : int, Date : str):
    DB = Connect_DB()

    Data = Use_DB(DB, f'Select * from `lessons` where `group_id` = {Group} and `date` = "{Date}"')

    Close_DB(DB)
    return Data

def Check_Office (Office : int):
    DB = Connect_DB()

    Data = Use_DB(DB, f'Select `name` from `office` where `id` = {Office}')
    Data = Data[0][0]

    Close_DB(DB)
    return Data

# Telegram-бот
Bot = telebot.TeleBot(TG_Token)

@Bot.message_handler(commands=['start']) # Меню бота
def Start (message : telebot.types.Message):
    if Check_T_ID (message.chat.id):
        keyboard = telebot.types.InlineKeyboardMarkup()
        Button_Log = telebot.types.InlineKeyboardButton("Расписание", callback_data='Schedule')
        keyboard.add(Button_Log)
        Bot.send_message(message.chat.id,
                        f"Приветствую, {Check_Username(message.chat.id)}. \nСегодня {datetime.date.today().strftime("%d.%m.%Y")}",
                        reply_markup=keyboard)

    else:
        keyboard = telebot.types.InlineKeyboardMarkup()
        Button_Log = telebot.types.InlineKeyboardButton("Есть аккаунт", callback_data='Login')
        Button_Reg = telebot.types.InlineKeyboardButton("Нет аккаунта", callback_data='Registration')
        keyboard.add(Button_Log)
        keyboard.add(Button_Reg)
        Bot.send_message(message.chat.id,
                         f"Вы не вошли в систему! \nВыберите действие:",
                         reply_markup=keyboard)
        
@Bot.message_handler(commands=['login'])
def Login (message : telebot.types.Message):
    Sent = Bot.send_message(message.chat.id,
                         "Авторизация \nВведите логин:")
    
    Bot.register_next_step_handler(Sent, Login_Password)

def Login_Password(message : telebot.types.Message):
    User_Save_Str(message.chat.id, "Login", message.text)

    Sent = Bot.send_message(message.chat.id,
                     'Авторизация \nВведите пароль:')

    Bot.register_next_step_handler(Sent, Login_Password_Save)

def Login_Password_Save(message : telebot.types.Message):
    User_Save_Str(message.chat.id, "Password", SHA224(message.text))
    Data = User_Data[message.chat.id]

    if Check_Login(Data["Login"]) and Check_Password(Data["Password"]):
        Update_User(message.chat.id, Data["Login"])

        Start(message)
    else:
        Bot.send_message(message.chat.id,
                     f'Неправильно введён логин или пароль!')
        
@Bot.message_handler(commands=['registration'])
def Registration(message : telebot.types.Message): #Ник, Пароль, ФИО, Группа
    Sent = Bot.send_message(message.chat.id,
                     f'Регистрация \nПример: Aboba \nВведите ник:')
    
    Bot.register_next_step_handler(Sent, Registration_2)

def Registration_2 (message : telebot.types.Message):
    User_Save_Str(message.chat.id, "Login", message.text)

    Sent = Bot.send_message(message.chat.id,
                     f'Регистрация \nПример: 12345 \nВведите пароль:')
    
    Bot.register_next_step_handler(Sent, Registration_3)

def Registration_3 (message : telebot.types.Message):
    User_Save_Str(message.chat.id, "Password", SHA224(message.text))

    Sent = Bot.send_message(message.chat.id,
                     f'Регистрация \nПример: Вам тут пример нужен -_- \nВведите ФИО:')
    
    Bot.register_next_step_handler(Sent, Registration_4)

def Registration_4 (message : telebot.types.Message):
    User_Save_Str(message.chat.id, "FIO", message.text)

    Sent = Bot.send_message(message.chat.id,
                     f'Регистрация \nЕсли вы из ИС-22, то 1, если из ИСп-22, то 2 \nВведите номер группы:')
    
    Bot.register_next_step_handler(Sent, Registration_5)

def Registration_5 (message : telebot.types.Message):
    User_Save_Int(message.chat.id, "Group", int(message.text))

    Data = User_Data[message.chat.id]

    Reg(Data["Username"], Data["Password"], Data["FIO"], Data["Group"], message.chat.id)
    Bot.send_message(message.chat.id,
                     f'Спасибо за регистрацию!')
    
    Start(message)

def Schedule (message : telebot.types.Message):
    lessons = Check_Schedule(Check_Group(message.chat.id), datetime.date.today().strftime("%Y-%m-%d"))

    if not lessons:
         Bot.send_message(message.chat.id,
                     f'Пар сегодня нет!')
    else:
        Text = ""

        for i in range(len(lessons)):
            Text += f"{lessons[i][6]} пара - {lessons[i][1]} в {Check_Office(lessons[i][2])} кабинете."

        Bot.send_message(message.chat.id,
                        Text)

@Bot.callback_query_handler(func=lambda call: True) # Обработка callback
def Handle_Query(call : telebot.types.CallbackQuery):
    def Handle_Login (call : telebot.types.CallbackQuery):
        Login(call.message)

    def Handle_Registration (call : telebot.types.CallbackQuery):
        Registration(call.message)

    def Handle_Schedule (call : telebot.types.CallbackQuery):
        Schedule(call.message)

    Actions = {
        'Login': lambda Param: Handle_Login(Param),
        'Registration': lambda Param: Handle_Registration(Param),
        'Schedule': lambda Param: Handle_Schedule(Param)
    }

    Actions.get(call.data)(call)

Bot.infinity_polling()